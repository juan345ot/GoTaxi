# GoTaxiPassengerApp

Aplicación móvil para pasajeros de GoTaxi.

## Scripts disponibles

- `npm start`: Inicia el servidor de desarrollo.
- `npm run android`: Corre la app en un emulador Android.
- `npm run ios`: Corre la app en un emulador iOS (solo en Mac).
- `npm run web`: Corre la app en navegador web.